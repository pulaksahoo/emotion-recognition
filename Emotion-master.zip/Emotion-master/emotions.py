import cv2
import numpy as np
from keras.models import load_model
from statistics import mode
from utils.datasets import get_labels
from utils.inference import detect_faces
from utils.inference import draw_text
from utils.inference import draw_bounding_box
from utils.inference import apply_offsets
from utils.inference import load_detection_model
from utils.preprocessor import preprocess_input
import subprocess
from pydub import AudioSegment
import speech_recognition as sr
from textblob import TextBlob
from textblob.sentiments import NaiveBayesAnalyzer
import matplotlib.pyplot as plt

USE_WEBCAM = True # If false, loads video file source

# parameters for loading data and images
emotion_model_path = './models/emotion_model.hdf5'
emotion_labels = get_labels('fer2013')

# hyper-parameters for bounding boxes shape
frame_window = 10
emotion_offsets = (20, 40)

# loading models
face_cascade = cv2.CascadeClassifier('./models/haarcascade_frontalface_default.xml')
emotion_classifier = load_model(emotion_model_path)

# getting input model shapes for inference
emotion_target_size = emotion_classifier.input_shape[1:3]

# starting lists for calculating modes
emotion_window = []

# starting video streaming

#cv2.namedWindow('window_frame')
#video_capture = cv2.VideoCapture(0)

# Select video or webcam feed
cap = None
#if (USE_WEBCAM == True):
#    cap = cv2.VideoCapture(0) # Webcam source
#else:
# cap = cv2.VideoCapture('./demo/dinner.mp4') # Video file source
cap = cv2.VideoCapture('./demo/priyanka.mp4')
# cap = cv2.VideoCapture('./demo/movies7.mp')
# cap = cv2.VideoCapture('./movies7.mp4') # Video file source
# cap = cv2.VideoCapture(0)
probability=[0,0,0]
count=0
def audioanalyze():
    command = "ffmpeg -i ./demo/priyanka.mp4 -ab 160k -ac 2 -ar 44100 -vn audio.wav"

    subprocess.call(command, shell=True)

    AUDIO_FILE = ("audio.wav")
    sound = AudioSegment.from_file(AUDIO_FILE)



    # use the audio file as the audio source

    r = sr.Recognizer()
    audio=sr.AudioFile(AUDIO_FILE)
    text=""
    off=0
    dur=10
    # for i in range(0,7):
    with audio as source:
        #reads the audio file. Here we use record instead of
        #listen
        # audio = r.record(source)
    	audio1 = r.record(source,duration=20)

    		# audio1 = r.record(source,offset=(off+(dur*i)),duration=dur)
    	    # text=text+" "+r.recognize_google(audio)
    try:
        print(" Converted Text :- \n "+r.recognize_google(audio1))
        # print(textblob.polarity(r.recognize_google(audio1)))
        blob = TextBlob(r.recognize_google(audio1),analyzer=NaiveBayesAnalyzer())
        print(blob.sentiment)
        return blob.sentiment.p_pos,blob.sentiment.p_neg
    	# text=text+" "+r.recognize_google(audio1)
    except sr.UnknownValueError:
    	print("Google Speech Recognition could not understand audio")

    except sr.RequestError as e:
    	print("Could not request results from Google Speech Recognition service; {0}".format(e))

try:

    while cap.isOpened(): # True:
        ret, bgr_image = cap.read()

        # bgr_image = video_capture.read()[1]

        gray_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2GRAY)
        rgb_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)

        faces = face_cascade.detectMultiScale(gray_image, scaleFactor=1.1, minNeighbors=5,
    			minSize=(30, 30), flags=cv2.CASCADE_SCALE_IMAGE)

        for face_coordinates in faces:

            x1, x2, y1, y2 = apply_offsets(face_coordinates, emotion_offsets)
            gray_face = gray_image[y1:y2, x1:x2]
            try:
                gray_face = cv2.resize(gray_face, (emotion_target_size))
            except:
                continue

            gray_face = preprocess_input(gray_face, True)
            gray_face = np.expand_dims(gray_face, 0)
            gray_face = np.expand_dims(gray_face, -1)
            emotion_prediction = emotion_classifier.predict(gray_face)
            print('hello',emotion_prediction[0])
            probability[0]+=emotion_prediction[0][0]
            probability[1]+=emotion_prediction[0][1]
            probability[2]+=emotion_prediction[0][2]
            count+=1
            emotion_probability = np.max(emotion_prediction)
            print('hi',emotion_probability)
            emotion_label_arg = np.argmax(emotion_prediction)
            emotion_text = emotion_labels[emotion_label_arg]
            print(emotion_text)
            emotion_window.append(emotion_text)

            if len(emotion_window) > frame_window:
                emotion_window.pop(0)
            try:
                emotion_mode = mode(emotion_window)
            except:
                continue

            if emotion_text == 'posetive':
                color = emotion_probability * np.asarray((255, 0, 0))
            elif emotion_text == 'neutral':
                color = emotion_probability * np.asarray((0, 0, 255))
            elif emotion_text == 'negative':
                color = emotion_probability * np.asarray((255, 255, 0))
            else:
                color = emotion_probability * np.asarray((0, 255, 0))

            color = color.astype(int)
            color = color.tolist()

            draw_bounding_box(face_coordinates, rgb_image, color)
            draw_text(face_coordinates, rgb_image, emotion_mode,
                      color, 0, -45, 1, 1)

        bgr_image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)
        cv2.imshow('window_frame', bgr_image)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
except:
    cv2.destroyAllWindows()
    print("Positive= ",(probability[2]+probability[1])/count)
    posetive=(probability[2]+probability[1])/count
    print("Negative= ",probability[0]/count)
    negative=probability[0]/count
    audiovalue=audioanalyze()
    posetive=(posetive+audiovalue[0])/2
    negative=(negative+audiovalue[1])/2
    print(audiovalue)
    # Pie chart, where the slices will be ordered and plotted counter-clockwise:
    labels = 'Positive', 'Negative'
    sizes = [posetive,negative]
    print(sizes)
    explode = (0, 0)  # only "explode" the 2nd slice (i.e. 'Hogs')
    colors = ['yellowgreen', 'lightcoral']

    # fig1, ax1 = plt.subplots()
    plt.pie(sizes, explode=explode, labels=labels, colors=colors,
    autopct='%1.1f%%', shadow=False, startangle=140)
    plt.axis('equal') # Equal aspect ratio ensures that pie is drawn as a circle.

    plt.show()
    cap.release()
    exit()
    pass

cap.release()
cv2.destroyAllWindows()
