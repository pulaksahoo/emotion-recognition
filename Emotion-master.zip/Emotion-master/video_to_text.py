import subprocess
from pydub import AudioSegment
import speech_recognition as sr
from textblob import TextBlob
from textblob.sentiments import NaiveBayesAnalyzer


command = "ffmpeg -i ./demo/priyanka.mp4 -ab 160k -ac 2 -ar 44100 -vn audio.wav"

subprocess.call(command, shell=True)

AUDIO_FILE = ("audio.wav")
sound = AudioSegment.from_file(AUDIO_FILE)

# halfway_point = len(sound) // 2
# first_half = sound[:halfway_point]
# second_half= sound[halfway_point:]

# create a new file "first_half.mp3":
# first_half.export("first_half.wav", format="wav")
# second_half.export("second_half.wav", format="wav")



# AUDIO_FILE = ("english.wav")
# AUDIO_FILE = ("audio.wav")
# AUDIO_FILE = ("second_half.wav")
# AUDIO_FILE = ("first_half.wav")

# use the audio file as the audio source

r = sr.Recognizer()
audio=sr.AudioFile(AUDIO_FILE)
text=""
off=0
dur=10
# for i in range(0,7):
with audio as source:
    #reads the audio file. Here we use record instead of
    #listen
    # audio = r.record(source)
	audio1 = r.record(source,duration=20)

		# audio1 = r.record(source,offset=(off+(dur*i)),duration=dur)
	    # text=text+" "+r.recognize_google(audio)
try:
    print(" Converted Text :- \n "+r.recognize_google(audio1))
    # print(textblob.polarity(r.recognize_google(audio1)))
    blob = TextBlob(r.recognize_google(audio1),analyzer=NaiveBayesAnalyzer())
    print(blob.sentiment)
	# text=text+" "+r.recognize_google(audio1)
except sr.UnknownValueError:
	print("Google Speech Recognition could not understand audio")

except sr.RequestError as e:
	print("Could not request results from Google Speech Recognition service; {0}".format(e))


# print(" Converted Text :- \n "+text+"\n")
